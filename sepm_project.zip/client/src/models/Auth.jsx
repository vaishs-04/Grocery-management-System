import { useContext, useState } from "react";
import { AppContext } from "../context/AppContext";
import toast from "react-hot-toast";
const Auth = () => {
    const [state, setState] = useState("login");
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const {setShowUserLogin, setUser, axios, navigate} = useContext(AppContext);
    const [loading, setLoading] = useState(false);
    
//     const submitHandler = async(e) => {
        
//         try {
//         e.preventDefault();
//         const { data } = await axios.post(`/api/user/register`, {
//          name,
//          email,
//          password,
//         });
//         if (data.success) {
//             toast.success(data.message);
//             navigate("/");
//             setUser(data.user);
//             setShowUserLogin(false);
//         } else {
//             toast.error(data.message);
//         }
//         } catch (error) {}
//    };
    const submitHandler = async (e) => {
    e.preventDefault();
    setLoading(true); // Start loading
    try {
        const endpoint = state === "login" ? "/api/user/login" : "/api/user/register";
        const payload = state === "register" ? { name, email, password } : { email, password };

        const { data } = await axios.post(endpoint, payload);

        if (data.success) {
            toast.success(data.message);
            setUser(data.user);
            setShowUserLogin(false);
            if (state === "register") navigate("/"); 
        } else {
            toast.error(data.message);
        }
    } catch (error) {
        toast.error(error.response?.data?.message || "Something went wrong");
    } finally {
        setLoading(false); // Stop loading regardless of success or failure
    }
    };
    return (
        <div 
        onClick={() => setShowUserLogin(false)}
        className="fixed top-0 bottom-0 left-0 right-0 z-40 flex items-center
        justify-center bg-black/50 text-gray-600"> 
            <form  
            onClick={(e) => e.stopPropagation()}
            onSubmit = {submitHandler}
            className="flex flex-col gap-4 m-auto items-start p-8 py-12 w-80 sm:w-88 text-gray-500 rounded-lg shadow-xl border border-gray-200 bg-white">
            <p className="text-2xl font-medium m-auto">
                <span className="text-indigo-500">User</span> {state === "login" ? "Login" : "Sign Up"}
            </p>
            {state === "register" && (
                <div className="w-full">
                    <p>Name</p>
                    <input onChange={(e) => setName(e.target.value)} value={name} placeholder="type here" className="border border-gray-200 rounded w-full p-2 mt-1 outline-indigo-500" type="text" required />
                </div>
            )}
            <div className="w-full ">
                <p>Email</p>
                <input onChange={(e) => setEmail(e.target.value)} value={email} placeholder="type here" className="border border-gray-200 rounded w-full p-2 mt-1 outline-indigo-500" type="email" required />
            </div>
            <div className="w-full ">
                <p>Password</p>
                <input onChange={(e) => setPassword(e.target.value)} value={password} placeholder="type here" className="border border-gray-200 rounded w-full p-2 mt-1 outline-indigo-500" type="password" required />
            </div>
            {state === "register" ? (
                <p>
                    Already have account? <span onClick={() => setState("login")} className="text-indigo-500 cursor-pointer">click here</span>
                </p>
            ) : (
                <p>
                    Create an account? <span onClick={() => setState("register")} className="text-indigo-500 cursor-pointer">click here</span>
                </p>
            )}
            <button 
                disabled={loading} // Prevent multiple clicks
                className={`bg-indigo-500 hover:bg-indigo-600 transition-all text-white w-full py-2 rounded-md cursor-pointer flex justify-center items-center gap-2 ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
                {loading ? (
                    <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        {state === "register" ? "Creating..." : "Logging in..."}
                    </>
                ) : (
                    state === "register" ? "Create Account" : "Login"
                )}
            </button>
        </form>
        </div>
    );
};
export default Auth
