// import { createContext, useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import {dummyProducts} from "../assets/assets";
// import toast from "react-hot-toast";
// import axios from "axios";
// axios.defaults.withCredentials = true;
// axios.defaults.baseURL = import.meta.env.VITE_BACKEND_URL;
// export const AppContext = createContext(null);

// const AppContextProvider = ({ children}) => {
//     const navigate = useNavigate();
//     const [user, setUser] = useState(null);
//     const [isSeller, setIsSeller] = useState(null);
//     const [showUserLogin, setShowUserLogin] = useState(false);
//     const[products, setProducts] = useState([]);
//     const [cartItems, setCartItems] = useState({});
//     const [searchQuery, setSearchQuery] = useState({});

//     // check seller status
//     const fetchSeller = async () => {
//     try {
//       const { data } = await axios.get("/api/seller/is-auth");
//       setIsSeller(data.success);
//       // if (data.success) {
//       //   setIsSeller(true);
//       // } else {
//       //   setIsSeller(false);
//       // }
//     } catch (error) {
//       setIsSeller(false);
//     }
//     };

//     // fetch user auth status ,user Data and cart items
//     const fetchUser = async () => {
//     try {
//         const { data } = await axios.get("/api/user/is-auth");
//         if (data.success) {
//             setUser(data.user);
//             setCartItems(data.user.cart);
//         }
//     } catch (error) {
//         // REMOVE the toast.error here! 
//         // If the user isn't logged in, it's not an "error" we need to show the user.
//         setUser(null); 
//     }
//     };

//     //fetch all products
//     const fetchProducts = async () => {
//     try {
//       const { data } = await axios.get("/api/product/get");
//       if (data.success) {
//         setProducts(data.products);
//       } else {
//         toast.error(data.message);
//       }
//     } catch (error) {
//       toast.error(error.message);
//     }
//   };

//     //add prod to cart

//     const addToCart = (itemId) => {
//     let cartData = structuredClone(cartItems || {}); // safeguard for undefined

//     if (cartData[itemId]) {
//       cartData[itemId] += 1;
//     } else {
//       cartData[itemId] = 1;
//     }

//     setCartItems(cartData);
//     toast.success("Added to cart");
//     };

//     // update cart item quantity
//     const updateCartItem = (itemId, quantity) => {
//     let cartData = structuredClone(cartItems);
//     cartData[itemId] = quantity;
//     setCartItems(cartData);
//     toast.success(`cart updated`);
//     };

//      // total cart items
//     const cartCount = () => {
//     let totalCount = 0;
//     for (const item in cartItems) {
//       totalCount += cartItems[item];
//     }
//     return totalCount;
//     };

//     // total cart amount
//     // const totalCartAmount = () => {
//     // let totalAmount = 0;
//     // for (const items in cartItems) {
//     //   let itemInfo = products.find((product) => product._id === items);
//     //   if (cartItems[items] > 0) {
//     //     totalAmount += cartItems[items] * itemInfo.offerPrice;
//     //   }
//     // }
//     // return Math.floor(totalAmount * 100) / 100;
//     // };
//     const totalCartAmount = () => {
//     let totalAmount = 0;
//     for (const items in cartItems) {
//         // Find the product
//         let itemInfo = products.find((product) => product._id === items);
        
//         // SAFEGUARD: Check if itemInfo exists before accessing offerPrice
//         if (itemInfo && cartItems[items] > 0) {
//             totalAmount += cartItems[items] * itemInfo.offerPrice;
//         }
//     }
//     return Math.floor(totalAmount * 100) / 100;
//   };

//      // remove product from cart
//     const removeFromCart = (itemId) => {
//     let cartData = structuredClone(cartItems);
//     if (cartData[itemId]) {
//       cartData[itemId] -= 1;
//       if (cartData[itemId] === 0) {
//         delete cartData[itemId];
//       }
//       toast.success(`remove from cart`);
//       setCartItems(cartData);
//     }
//     };

//     useEffect(() => {
//         fetchProducts();
//         fetchSeller();
//         fetchUser();
//     }, []);

//     const value = {
//         navigate,
//         user, 
//         setUser,
//         isSeller,
//         setIsSeller,
//         showUserLogin,
//         setShowUserLogin,
//         products,
//         addToCart,
//         updateCartItem,
//         cartCount,
//         totalCartAmount,
//         removeFromCart,
//         cartItems,
//         searchQuery,
//         setSearchQuery,
//         axios,
//         fetchProducts,
//     };
//     return <AppContext.Provider value= {value}>{children}</AppContext.Provider>;
// };

// export default AppContextProvider;

import { createContext, useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { dummyProducts } from "../assets/assets";
import toast from "react-hot-toast";
import axios from "axios";
axios.defaults.withCredentials = true;
axios.defaults.baseURL = import.meta.env.VITE_BACKEND_URL;
export const AppContext = createContext(null);

export const AppContextProvider = ({ children }) => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [isSeller, setIsSeller] = useState(false);
  const [showUserLogin, setShowUserLogin] = useState(false);
  const [products, setProducts] = useState([]);
  const [cartItems, setCartItems] = useState({});
  const [searchQuery, setSearchQuery] = useState("");

  // check seller status
  const fetchSeller = async () => {
    try {
      const { data } = await axios.get("/api/seller/is-auth");
      setIsSeller(!!data.success); //RA
      // if (data.success) {
      //   setIsSeller(true);
      // } else {
      //   setIsSeller(false);
      // }
    } catch (error) {
      setIsSeller(false);
    }
  };

  // fetch user auth status ,user Data and cart items
  const fetchUser = async () => {
    try {
      const { data } = await axios.get("/api/user/is-auth");
      if (data.success) {
        setUser(data.user);
        setCartItems(data.user.cart || {}); //recent add
      }
      //  else {
      //   toast.error(data.message);
      // }
    } catch (error) {
      // toast.error(error.message);
      setUser(null);
    }
  };

  // fetch products
  const fetchProducts = async () => {
    try {
      const { data } = await axios.get("/api/product/get");
      if (data.success) {
        setProducts(data.products);
      } 
      // else {
      //   toast.error(data.message);
      // }
    } catch (error) {
      toast.error(error.message);
    }
  };
  // add product to cart
  const addToCart = (itemId) => {
    let cartData = structuredClone(cartItems || {}); // safeguard for undefined

    if (cartData[itemId]) {
      cartData[itemId] += 1;
    } else {
      cartData[itemId] = 1;
    }

    setCartItems(cartData);
    toast.success("Added to cart");
  };

  // update cart item quantity
  const updateCartItem = (itemId, quantity) => {
    let cartData = structuredClone(cartItems);
    cartData[itemId] = quantity;
    setCartItems(cartData);
    toast.success(`cart updated`);
  };

  // total cart items
  const cartCount = () => {
    let totalCount = 0;
    for (const item in cartItems) {
      totalCount += cartItems[item];
    }
    return totalCount;
  };
  // total cart amount
  const totalCartAmount = () => {
    let totalAmount = 0;
    for (const items in cartItems) {
      let itemInfo = products.find((product) => product._id === items);
      if (cartItems[items] > 0) {
        totalAmount += cartItems[items] * itemInfo.offerPrice;
      }
    }
    return Math.floor(totalAmount * 100) / 100;
  };
  // remove product from cart
  const removeFromCart = (itemId) => {
    let cartData = structuredClone(cartItems);
    if (cartData[itemId]) {
      cartData[itemId] -= 1;
      if (cartData[itemId] === 0) {
        delete cartData[itemId];
      }
      toast.success(`remove from cart`);
      setCartItems(cartData);
    }
  };

   // update database cart items
  useEffect(() => {
    const updateCart = async () => {
      try {
        const { data } = await axios.post("/api/cart/update", { cartItems });

        if (!data.success) {
          toast.error(data.message);
        }
      } catch (error) {
        toast.error(error.message);
      }
    };

    if (user) {
      updateCart();
    }
  }, [cartItems]);
  
  useEffect(() => {
    fetchSeller();
    fetchProducts();
    fetchUser();
  }, []);

  // update database cart items
  useEffect(() => {
    const updateCart = async () => {
      try {
        const { data } = await axios.post("/api/cart/update", { cartItems });

        if (!data.success) {
          toast.error(data.message);
        }
      } catch (error) {
        toast.error(error.message);
      }
    };

    if (user) {
      updateCart();
    }
  }, [cartItems]);
  const value = {
    navigate,
    user,
    setUser,
    isSeller,
    setIsSeller,
    showUserLogin,
    setShowUserLogin,
    products,
    cartItems,
    addToCart,
    updateCartItem,
    removeFromCart,
    searchQuery,
    setSearchQuery,
    cartCount,
    totalCartAmount,
    axios,
    fetchProducts,
    setCartItems
  };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export default AppContextProvider;
